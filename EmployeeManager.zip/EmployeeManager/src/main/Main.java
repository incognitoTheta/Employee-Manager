package main;

import controllers.HomeController;
import java.io.IOException;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        
        HomeController hC = new HomeController();
        hC.primary = primaryStage;
        hC.fromOneGoToAll();
        hC.fromTwoGoOne();
        hC.fromThreeGoOne();
        hC.fromFourGoOne();
        hC.fromTwoGoFive();

        hC.primary.setScene(hC.scene1);
        hC.primary.initStyle(StageStyle.TRANSPARENT);
        hC.primary.show();
    }

    public static void main(String[] args) throws IOException {
        launch(args);

    }

}
