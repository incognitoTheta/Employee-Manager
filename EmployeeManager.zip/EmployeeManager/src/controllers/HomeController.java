package controllers;

import java.io.IOException;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class HomeController {

    @FXML
    public static Button insertBtn;

    @FXML
    private Button reviewBtn;
    @FXML
    private Button deleteBtn;

    public static Stage primary;
    public Scene scene1;
    public Scene scene2;
    public Scene scene3;
    public Scene scene4;
    public Scene scene5;
    public Scene scene6;

    public HomeController() {
    }
    static double dragOffsetX;
    static double dragOffsetY;

    //move scene method
    public static void moveScene(Scene scene) {

        scene.setOnMousePressed((MouseEvent event) -> {
            dragOffsetX = event.getScreenX() - primary.getX();
            dragOffsetY = event.getScreenY() - primary.getY();
        });
        scene.setOnMouseDragged((MouseEvent event) -> {
            primary.setX(event.getScreenX() - dragOffsetX);
            primary.setY(event.getScreenY() - dragOffsetY);
        });
    }

    @FXML
    public void closeApplication() {
        Platform.exit();
    }

    //Create Scene1 / Swich from Scene1 to other scenes
    public void fromOneGoToAll() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/home.fxml"));

        GridPane scene1Layout = loader.load();
        Button insertBtn = (Button) loader.getNamespace().get("insertBtn");
        Button updateBtn = (Button) loader.getNamespace().get("updateBtn");
        Button viewBtn = (Button) loader.getNamespace().get("viewBtn");
        Button deleteBtn = (Button) loader.getNamespace().get("deleteBtn");

        insertBtn.setOnAction(e -> {
            primary.setScene(scene2);
        });
        viewBtn.setOnAction(e -> {
            primary.setScene(scene3);
        });

        deleteBtn.setOnAction(e -> {
            primary.setScene(scene4);
        });
        updateBtn.setOnAction(e -> {
            primary.setScene(scene5);
        });

        scene1 = new Scene(scene1Layout, 500, 930);
        scene1.setFill(Color.TRANSPARENT);
        scene1.getStylesheets().add("css/style.css");
        moveScene(scene1);

    }

    //Create Scene2 / Switch to Scene1
    public void fromTwoGoOne() throws IOException {

        FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/views/insert.fxml"));

        GridPane scene2Layout = loader2.load();
        Button fromTwoGoOneButton = (Button) loader2.getNamespace().get("backBtn");

        fromTwoGoOneButton.setOnAction(e -> {
            primary.setScene(scene1);
            primary.setTitle("Home");
        });

        scene2 = new Scene(scene2Layout, 500, 930);
        scene2.setFill(Color.TRANSPARENT);
        scene2.getStylesheets().add("css/style.css");
        moveScene(scene2);
    }

    //Create Scene3 / Switch to Scene1
    public void fromThreeGoOne() throws IOException {

        FXMLLoader loader3 = new FXMLLoader(getClass().getResource("/views/view.fxml"));

        GridPane scene3Layout = loader3.load();
        Button fromThreeGoOneBtn = (Button) loader3.getNamespace().get("backButton");

        fromThreeGoOneBtn.setOnAction(e -> {
            primary.setScene(scene1);
            primary.setTitle("Home");
        });

        scene3 = new Scene(scene3Layout, 500, 930);
        scene3.setFill(Color.TRANSPARENT);
        scene3.getStylesheets().add("css/style.css");
        moveScene(scene3);

    }

    //Create Scene4 / Switch to Scene1
    public void fromFourGoOne() throws IOException {

        FXMLLoader loader4 = new FXMLLoader(getClass().getResource("/views/delete.fxml"));

        GridPane scene4Layout = loader4.load();
        Button fromFourGoOneBtn = (Button) loader4.getNamespace().get("backBtn");

        fromFourGoOneBtn.setOnAction(e -> {
            primary.setScene(scene1);
            primary.setTitle("Home");
        });

        scene4 = new Scene(scene4Layout, 500, 930);
        scene4.setFill(Color.TRANSPARENT);
        scene4.getStylesheets().add("css/style.css");
        moveScene(scene4);

    }

    //Create Scene5 / Switch to Scene1
    public void fromTwoGoFive() throws IOException {
        
        FXMLLoader loader5 = new FXMLLoader(getClass().getResource("/views/update.fxml"));

        GridPane scene5Layout = loader5.load();
        Button fromFiveGoOneButton = (Button) loader5.getNamespace().get("backBtn");

        fromFiveGoOneButton.setOnAction(e -> {
            primary.setScene(scene1);
            primary.setTitle("Home");
        });

        scene5 = new Scene(scene5Layout, 500, 930);
        scene5.setFill(Color.TRANSPARENT);
        scene5.getStylesheets().add("css/style.css");
        moveScene(scene5);
    }

}
