package models;

import java.io.Serializable;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Address implements Serializable {

    private final IntegerProperty address_id = new SimpleIntegerProperty(this, "address_id", 0);
    private final StringProperty address = new SimpleStringProperty(this, "address", "");
    private final StringProperty postal_code = new SimpleStringProperty(this, "postal_code", "");

    private final IntegerProperty city_id = new SimpleIntegerProperty(this, "city_id", 0);

    public Address(String address, String postal_code, int city_id) {
        this.address.set(address);
        this.postal_code.set(postal_code);
        this.city_id.set(city_id);
    }

    public Address(int address_id, String address, String postal_code, int city_id) {
        this.address_id.set(address_id);
        this.address.set(address);
        this.postal_code.set(postal_code);
        this.city_id.set(city_id);
    }

    public Address(int address_id) {
        this.address_id.set(address_id);
    }

    public Address() {

    }

    //read addresses from employee_db
    public static void readAddresses() {
        Address addr = null;
        ArrayList<Address> address_collection = new ArrayList<>();

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {
            Statement st = conn.createStatement();
            st.executeQuery("select * from viewaddress");
            ResultSet rs = st.getResultSet();
            while (rs.next()) {

                addr = new Address(rs.getString("address"), rs.getString("postal_code"), rs.getInt("city_id"));
                address_collection.add(addr);

                System.out.println(addr.toString());
            }
        } catch (SQLException ex) {
            System.out.println("Error in database connection: \n" + ex.getMessage());

        }
    }

    //insert address in employee_db
    public int insertAddress(String address, String postal_code, int city_id) {

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {
            Address addr = new Address(address, postal_code, city_id);
            PreparedStatement st = conn.prepareStatement("call insertAddress(?,?,?)");
            st.setString(1, addr.getAddress());
            st.setString(2, addr.getPostal_code());
            st.setString(3, String.valueOf(addr.getCity_id()));
            st.execute();
            try {

                ResultSet rs = st.getResultSet();

                while (rs.next()) {

                    address_id.set(Integer.parseInt(rs.getString(1)));

                }

            } catch (SQLException | NullPointerException e) {

            }
        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
        return address_id.get();
    }

    //update address in employee_db
    public void updateAddress(int address_id, String address, String postal_code, int city_id) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {
            Address addr = new Address(address_id, address, postal_code, city_id);
            PreparedStatement st = conn.prepareStatement("call updateAddress(?,?,?,?)");
            st.setString(1, String.valueOf(addr.getAddress_id()));
            st.setString(2, addr.getAddress());
            st.setString(3, addr.getPostal_code());
            st.setString(4, String.valueOf(addr.getCity_id()));
            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //delete address in employee_db
    public static void deleteAddress(int address_id) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Address addr = new Address(address_id);
            PreparedStatement st = conn.prepareStatement("call deleteAddress(?)");
            st.setString(1, String.valueOf(addr.getAddress_id()));
            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //check if the Address ID exists in employee_db
    public int verifyAddressID(int employeeID) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {
            PreparedStatement st = conn.prepareStatement("call verifyAddressID(?)");

            st.setInt(1, employeeID);
            st.execute();
            try {

                ResultSet rs = st.getResultSet();

                while (rs.next()) {

                    address_id.set(Integer.parseInt(rs.getString(1)));

                }

            } catch (SQLException | NullPointerException e) {

            }
        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
        return address_id.get();

    }

    public String getAddress() {
        return address.get();
    }

    public void setAddress(String address) {
        this.address.set(address);
    }

    public StringProperty addressProperty() {
        return address;
    }

    public String getPostal_code() {
        return postal_code.get();
    }

    public void setPostal_code(String postal_code) {
        this.postal_code.set(postal_code);
    }

    public StringProperty postal_codeProperty() {
        return postal_code;
    }

    public int getCity_id() {
        return city_id.get();
    }

    public void setCity_id(int city_id) {
        this.city_id.set(city_id);
    }

    public IntegerProperty city_idProperty() {
        return city_id;
    }

    public int getAddress_id() {
        return address_id.get();
    }

    public void setAddress_id(int address_id) {
        this.address_id.set(address_id);;
    }

    public IntegerProperty address_IdProperty() {
        return address_id;
    }

}
