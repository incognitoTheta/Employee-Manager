package controllers;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.StageStyle;
import models.Address;
import models.Employee;

public class UpdateController extends InsertController {

    @FXML
    TextField employeeID;
    @FXML
    private TextField firstName;
    @FXML
    private TextField age;
    @FXML
    private TextField salary;
    @FXML
    private TextField address;
    @FXML
    private TextField postalCode;
    @FXML
    private TextField phone;
    @FXML
    private ComboBox<String> city;
    @FXML
    private ComboBox<String> country;
    @FXML
    private Label msgLabel;
    @FXML
    private Label firstNameLabel;
    @FXML
    private Label ageLabel;
    @FXML
    private Label salaryLabel;
    @FXML
    private Label addressLabel;
    @FXML
    private Label postalCodeLabel;
    @FXML
    private Label phoneLabel;
    @FXML
    private Label countryLabel;
    @FXML
    private Label cityLabel;

    private int verifiedEmployeeID;
    private int result;

    //reset labels value
    public void reset() {

        msgLabel.setText("");
        firstNameLabel.setText("");
        ageLabel.setText("");
        salaryLabel.setText("");
        addressLabel.setText("");
        postalCodeLabel.setText("");
        phoneLabel.setText("");
        countryLabel.setText("");
        cityLabel.setText("");
    }

    //check if employee with first name and phone details exists in employee_db
    @FXML
    public String check() {

        reset();

        int result = Employee.verifyEmployeeIDByDetails(firstName.getText(), phone.getText());

        if (result == 0) {
            msgLabel.setText("Employee with inserted details does not exist!");
        } else {
            msgLabel.setText("Employee is valid!");
            verifiedEmployeeID = result;
        }

        if (firstName.getText().equals("") || phone.getText().equals("")) {
            msgLabel.setText("First name and phone must not be null");
        }
        return msgLabel.getText();
    }

    //update employee details in employee_db
    @FXML
    public void update() throws IOException {

        employeeID.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                employeeID.setText(newValue.replaceAll("[^\\d]", ""));

            }

        });

        result = 1;
        try {
            result = Employee.verifyEmployeeID(Integer.valueOf(employeeID.getText()));
        } catch (NumberFormatException nfe) {

        }

        if (result == 0) {
            reset();
            msgLabel.setText("Employee ID does not exist!");

        } else {
            msgLabel.setText("");
        }

        int empID = 0;
        try {

            empID = Integer.parseInt(employeeID.getText());

        } catch (NumberFormatException nfe) {
            msgLabel.setText("Employee ID must be a number");
        }
        if (!employeeID.getText().equals("")) {
            if (empID != 0) {

                if (!firstName.getText().equals("") && !age.getText().equals("") && !salary.getText().equals("")) {
                    if (!address.getText().equals("") && !postalCode.getText().equals("") && !phone.getText().equals("")) {

                        msgLabel.setText("");

                        boolean isCountry = (country.getValue() != null);
                        boolean isCity = (city.getValue() != null);

                        if (isCountry && isCity) {

                            Address add = new Address();
                            int employee_id = Integer.valueOf(employeeID.getText());
                            int address_id = add.verifyAddressID(employee_id);

                            add.updateAddress(address_id, address.getText(), postalCode.getText(), getSelectedCityID());

                            try {
                                Employee.updateEmployee(employee_id, firstName.getText(), Integer.valueOf(age.getText()), address_id, Double.parseDouble(salary.getText()), phone.getText());

                            } catch (NumberFormatException nfe) {
                                System.out.println("Employee update error!");
                            }

                            msgLabel.setText("You updated the following data:");
                            firstNameLabel.setText("First name: " + firstName.getText());
                            ageLabel.setText("Age: " + age.getText());
                            salaryLabel.setText("Salary: " + salary.getText());
                            addressLabel.setText("Address: " + address.getText());
                            postalCodeLabel.setText("Postal code: " + postalCode.getText());
                            phoneLabel.setText("Phone: " + phone.getText());
                            countryLabel.setText("Country: " + country.getSelectionModel().getSelectedItem());
                            cityLabel.setText("City: " + city.getSelectionModel().getSelectedItem());

                            if (result == 0) {
                                reset();
                                msgLabel.setText("Employee ID does not exist!");
                            }
                        }
                    }
                }
            }

        } else {

            msgLabel.setText("All fields except Employee ID must not be null");

            if (!firstName.getText().equals("") && !age.getText().equals("") && !salary.getText().equals("")) {
                if (!address.getText().equals("") && !postalCode.getText().equals("") && !phone.getText().equals("")) {
                    msgLabel.setText("You must press CHECK button first");
                    if (verifiedEmployeeID > 0) {

                        boolean isCountry = (country.getValue() != null);
                        boolean isCity = (city.getValue() != null);

                        if (isCountry && isCity) {

                            Address add = new Address();
                            int employee_id = verifiedEmployeeID;
                            int address_id = add.verifyAddressID(employee_id);

                            add.updateAddress(address_id, address.getText(), postalCode.getText(), getSelectedCityID());

                            try {
                                Employee.updateEmployee(verifiedEmployeeID, firstName.getText(), Integer.valueOf(age.getText()), address_id, Double.parseDouble(salary.getText()), phone.getText());

                            } catch (NumberFormatException nfe) {
                                System.out.println("Employee update error!");
                            }

                            msgLabel.setText("You updated the following data:");
                            firstNameLabel.setText("First name: " + firstName.getText());
                            ageLabel.setText("Age: " + age.getText());
                            salaryLabel.setText("Salary: " + salary.getText());
                            addressLabel.setText("Address: " + address.getText());
                            postalCodeLabel.setText("Postal code: " + postalCode.getText());
                            phoneLabel.setText("Phone: " + phone.getText());
                            countryLabel.setText("Country: " + country.getSelectionModel().getSelectedItem());
                            cityLabel.setText("City: " + city.getSelectionModel().getSelectedItem());
                            verifiedEmployeeID = 0;

                        } else {
                            msgLabel.setText("Country and City must not be null");
                        }
                    }
                }
            }
        }

    }

    //info scene from update view
    @FXML
    public void info() {

        Alert alert = new Alert(AlertType.INFORMATION);

        alert.setHeaderText("Informations");
        alert.initStyle(StageStyle.TRANSPARENT);

        String msg1 = "If 'Employee ID' is not inserted,\n"
                + "employee will be updated by 'First\n"
                + "name' and 'Phone' details.";

        String msg2 = "You can check if employee exist,\n"
                + "by entering data in 'First name' and\n"
                + "'Phone' fields and then press the\n"
                + "CHECK button.\n\n"
                + "If the employee exist then you can\n"
                + "enter the data in all fields for update."
                + "\n( except Employee ID field )\n";

        alert.setContentText(msg1 + "\n\n" + msg2 + "\n\n");

        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.getStylesheets().add("/css/style.css");
        alert.showAndWait().ifPresent(rs -> {

        });
    }
}
