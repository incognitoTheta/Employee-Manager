package models;

import java.io.Serializable;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Country implements Serializable {

    private final IntegerProperty country_id = new SimpleIntegerProperty(this, "country_id", 0);
    private final StringProperty country = new SimpleStringProperty(this, "country", "");

    public Country(String country) {
        this.country.set(country);
    }

    public Country(int country_id, String country) {
        this.country_id.set(country_id);
        this.country.set(country);
    }

    public Country() {

    }

    //read countries from employee_db
    public static void readCountries() {
        Country country = null;
        ArrayList<Country> city_collection = new ArrayList<>();

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {
            Statement st = conn.createStatement();
            st.executeQuery("select * from country");
            ResultSet rs = st.getResultSet();
            while (rs.next()) {

                country = new Country(rs.getString("country"));
                city_collection.add(country);

                System.out.println(country.toString());
            }
        } catch (SQLException ex) {
            System.out.println("Error in database connection: \n" + ex.getMessage());

        }
    }

    //insert city in employee_db
    public static void insertCountry(String country) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Country country_ = new Country(country);
            PreparedStatement st = conn.prepareStatement("call insertCountry(?)");
            st.setString(1, country_.getCountry());
            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //update city in employee_db
    public static void updateCountry(int country_id, String country) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Country country_ = new Country(country_id, country);
            PreparedStatement st = conn.prepareStatement("call updateCountry(?,?)");
            st.setString(1, String.valueOf(country_id));
            st.setString(2, country_.getCountry());
            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //delete city in employee_db
    public static void deleteCountry(String country) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Country country_ = new Country(country);
            PreparedStatement st = conn.prepareStatement("call deleteCountry(?)");
            st.setString(1, String.valueOf(country_.getCountry_id()));
            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String getCountry() {
        return country.get();
    }

    public void setCountry(String country) {
        this.country.set(country);
    }

    public StringProperty countryProperty() {
        return country;
    }

    public int getCountry_id() {
        return country_id.get();
    }

    public void setCountry_id(int country_id) {
        this.country_id.set(country_id);
    }

    public IntegerProperty country_idProperty() {
        return country_id;
    }

}
