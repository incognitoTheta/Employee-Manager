package controllers;

import java.util.ArrayList;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import models.Employee;

public class ViewController {

    @FXML
    private TextArea review;
    @FXML
    private TextField ageField;

    public static ArrayList<String> info;

    public ViewController() {

    }

//print employees details from employee_db in textarea
    @FXML
    public void view() {

        Employee em = new Employee();
        if (ageField.getText().equals("")) {
            review.setText(em.viewEmployees());
        } else {

            try {
                int age = Integer.valueOf(ageField.getText());

                if (age >= 14 && age <= 65) {
                    review.setText(em.ageGreaterOrEqualTo(age));

                } else {
                    review.setText("You must enter a number between 14 and 65");
                }
            } catch (NumberFormatException nfe) {
                review.setText("You must enter a number!");
            }
        }

    }

    @FXML
    public void closeApplication() {
        Platform.exit();
    }
}
