package controllers;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.StageStyle;
import models.Employee;

public class DeleteController {

    @FXML
    private TextField employeeID;
    @FXML
    private TextField firstName;
    @FXML
    private TextField phone;
    @FXML
    private Label msgLbl;

    private int verifiedEmployeeID;

    @FXML
    public void closeApplication() {
        Platform.exit();
    }

    public DeleteController() {

    }

    public void initialize() {
        employeeID.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                employeeID.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        phone.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                phone.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        firstName.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z*")) {
                firstName.setText(newValue.replaceAll("[^\\sa-zA-Z]", ""));
            }
        });
    }

    //check if employee with first name and phone details exists in employee_db
    public void check() {

        int result = Employee.verifyEmployeeIDByDetails(firstName.getText(), phone.getText());

        if (result == 0) {
            msgLbl.setText("Employee with this details does not exist");
        } else {
            msgLbl.setText("Employee deleted");
            verifiedEmployeeID = result;
        }

        if (firstName.getText().equals("") || phone.getText().equals("")) {
            msgLbl.setText("First name and phone must not be null");
        }

    }

    //info scene from delete view
    @FXML
    public void info() {

        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setHeaderText("Info");
        alert.initStyle(StageStyle.TRANSPARENT);

        String msg1 = "If 'Employee ID' is not inserted,\n"
                + "employee will be deleted by 'First\n"
                + "name' and 'Phone' details.";

        String msg2 = "You can check if employee exist,\n"
                + "by entering data in 'First name' and\n"
                + "'Phone' fields and then press the\n"
                + "DELETE button.\n\n"
                + "If the employee exist then he will\n"
                + "be deleted.\n";

        alert.setContentText(msg1 + "\n\n" + msg2 + "\n\n");

        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.getStylesheets().add("/css/style.css");
        alert.showAndWait().ifPresent(rs -> {

        });

    }

    //delete employee details in employee_db
    @FXML
    public void deleteEmployee() {

        int employee_id = 0;

        try {
            if (!employeeID.getText().equals("")) {

                employee_id = Employee.verifyEmployeeID(Integer.parseInt(employeeID.getText()));

                if (employee_id != 0) {

                    Employee.deleteEmployee(Integer.parseInt(employeeID.getText()));
                    msgLbl.setText("Employee with ID " + employeeID.getText() + " was deleted");

                } else {
                    msgLbl.setText("Employee with ID " + employeeID.getText() + " does not exist!");
                }
            } else {
                if (employee_id != 0) {
                    msgLbl.setText("Employee with ID " + verifiedEmployeeID + " deleted");

                }
                check();
                Employee.deleteEmployee(verifiedEmployeeID);

            }

        } catch (NumberFormatException | NullPointerException e) {

            msgLbl.setText("You must enter a number!");
        }

    }

}
