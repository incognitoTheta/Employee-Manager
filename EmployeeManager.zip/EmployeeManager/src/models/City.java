package models;

import java.io.Serializable;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class City implements Serializable {

    private final IntegerProperty city_id = new SimpleIntegerProperty(this, "city_id", 0);
    private final StringProperty city = new SimpleStringProperty(this, "city", "");
    private final IntegerProperty country_id = new SimpleIntegerProperty(this, "country_id", 0);

    public City(String city, int country_id) {
        this.city.set(city);
        this.country_id.set(country_id);
    }

    public City(int city_id, String city, int country_id) {
        this.city.set(city);
        this.country_id.set(country_id);
    }

    public City(int city_id) {
        this.city_id.set(city_id);

    }

    public City(String city) {
        this.city.set(city);
    }

    public City() {

    }

    //read cities from employee_db
    public static void readCities() {
        City city = null;
        ArrayList<City> city_collection = new ArrayList<>();

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {
            Statement st = conn.createStatement();
            st.executeQuery("select * from viewcity");
            ResultSet rs = st.getResultSet();
            while (rs.next()) {

                city = new City(rs.getString("city"), rs.getInt("country_id"));
                city_collection.add(city);

                System.out.println(city.toString());
            }
        } catch (SQLException ex) {
            System.out.println("Error in database connection: \n" + ex.getMessage());

        }
    }

    //insert city in employee_db
    public static void insertCity(String city, int country_id) {

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            City city_ = new City(city, country_id);

            PreparedStatement st = conn.prepareStatement("call insertCity(?,?)");

            st.setString(1, city_.getCity());
            st.setString(2, String.valueOf(city_.getCountry_id()));

            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //update city in employee_db
    public static void updateCity(int city_id, String city, int country_id) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {
            City city_ = new City(city_id, city, country_id);
            PreparedStatement st = conn.prepareStatement("call updateCity(?,?,?)");
            st.setString(1, String.valueOf(city_.getCity_id()));
            st.setString(2, city_.getCity());
            st.setString(3, String.valueOf(city_.getCountry_id()));

            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //delete city in employee_db
    public static void deleteCity(int city_id) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            City city_ = new City(city_id);
            PreparedStatement st = conn.prepareStatement("call insertCity(?)");
            st.setString(1, String.valueOf(city_.getCity_id()));
            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //check if the City ID exists in employee_db
    public int checkCityID(String cityName) {

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            PreparedStatement st = conn.prepareStatement("call checkCityID(?)");
            st.setString(1, cityName);
            st.execute();

            try {

                ResultSet rs = st.getResultSet();

                while (rs.next()) {

                    city_id.set(Integer.parseInt(rs.getString(1)));

                }

            } catch (SQLException | NullPointerException e) {

            }
        } catch (SQLException ex) {
            System.out.println("Error in database connection: \n" + ex.getMessage());

        }
        return city_id.get();
    }

    public String getCity() {
        return city.get();
    }

    public void setCity(String city) {
        this.city.set(city);
    }

    public StringProperty cityProperty() {
        return city;
    }

    public int getCountry_id() {
        return country_id.get();
    }

    public void setCountry_id(int country_id) {
        this.country_id.set(country_id);
    }

    public IntegerProperty country_idProperty() {
        return country_id;
    }

    public int getCity_id() {
        return city_id.get();
    }

    public void setCity_id(int city_id) {
        this.city_id.set(city_id);
    }

    public IntegerProperty city_idProperty() {
        return city_id;
    }

}
