package models;

import java.io.Serializable;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Employee implements Serializable {

    private final IntegerProperty employee_id = new SimpleIntegerProperty(this, "employee_id", 0);
    private final StringProperty first_name = new SimpleStringProperty(this, "first_name", "");
    private final IntegerProperty age = new SimpleIntegerProperty(this, "age", 0);
    private final IntegerProperty address_id = new SimpleIntegerProperty(this, "address_id", 0);
    private final DoubleProperty salary = new SimpleDoubleProperty(this, "salary", 0);
    private final StringProperty country = new SimpleStringProperty(this, "country", "");
    private final StringProperty city = new SimpleStringProperty(this, "city", "");
    private final StringProperty phone = new SimpleStringProperty(this, "phone", "");

    private String address;
    private String postalCode;
    private String phone_;

    static StringBuilder sb = new StringBuilder();

    public Employee(String first_name, int age, int address_id, double salary, String phone) {
        this.first_name.set(first_name);
        this.age.set(age);
        this.address_id.set(address_id);
        this.salary.set(salary);
        this.phone.set(phone);
    }

    public Employee(String first_name, int age, int address_id, double salary) {
        this.first_name.set(first_name);
        this.age.set(age);
        this.address_id.set(address_id);
        this.salary.set(salary);
    }

    public Employee(int employee_id, String first_name, int age, int address_id, double salary, String phone) {
        this.employee_id.set(employee_id);
        this.first_name.set(first_name);
        this.age.set(age);
        this.address_id.set(address_id);
        this.salary.set(salary);
        this.phone.set(phone);
    }

    public Employee(int employee_id) {
        this.employee_id.set(employee_id);
    }

    public Employee() {

    }

    //insert employee data in employee_db
    public static void insertEmployee(String first_name, int age, int address_id, double salary, String phone) {

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Employee employee = new Employee(first_name, age, address_id, salary, phone);
            PreparedStatement st = conn.prepareStatement("call insertEmployee(?,?,?,?,?)");

            st.setString(1, employee.getFirstName());
            st.setString(2, String.valueOf(employee.getAge()));
            st.setString(3, String.valueOf(employee.getAddress_id()));
            st.setString(4, String.valueOf(employee.getSalary()));
            st.setString(5, employee.getPhone());

            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //update employee data in employee_db
    public static void updateEmployee(int employee_id, String first_name, int age, int address_id, double salary, String phone) {

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Employee employee = new Employee(employee_id, first_name, age, address_id, salary, phone);
            PreparedStatement st = conn.prepareStatement("call updateEmployee(?,?,?,?,?,?)");

            st.setInt(1, employee.getEmployee_id());
            st.setString(2, employee.getFirstName());
            st.setInt(3, employee.getAge());
            st.setInt(4, employee.getAddress_id());
            st.setDouble(5, employee.getSalary());
            st.setString(6, employee.getPhone());
            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //delete employees data in employee_db
    public static void deleteEmployee(int employee_id) {
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Employee employee = new Employee(employee_id);
            PreparedStatement st = conn.prepareStatement("call deleteEmployee(?)");
            st.setString(1, String.valueOf(employee.getEmployee_id()));
            st.execute();

        } catch (SQLException ex) {
            Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //read employees data from employee_db
    public String viewEmployees() {

        sb = new StringBuilder();
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Statement st = conn.createStatement();
            st.executeQuery("select * from viewem");
            ResultSet rs = st.getResultSet();

            while (rs.next()) {

                first_name.set(rs.getString(2));
                age.set(rs.getInt(3));
                salary.set(rs.getDouble(4));
                address = rs.getString(6);
                postalCode = (rs.getString(7));
                phone_ = rs.getString(8);
                country.set(rs.getString(9));
                city.set(rs.getString(10));

                sb.append("First name: " + first_name.get() + "\nAge: " + age.get() + "\nSalary: " + salary.get() + "\nAddress: " + address + "\n"
                        + "Postal code: " + postalCode + "\n"
                        + "Phone: " + phone_ + "\n"
                        + "Country: " + country.get() + "\n"
                        + "City: " + city.get() + "\n");
                sb.append("____________________________________________________________\n");

            }
        } catch (SQLException ex) {
            sb.append(ex.getMessage());

        }
        return sb.toString();
    }

    //filter employees by age grater than parameter
    public String ageGreaterOrEqualTo(int ageNum) {

        sb = new StringBuilder();
        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Statement st = conn.createStatement();
            st.executeQuery("call ageGreaterOrEqualTo(" + ageNum + ")");
            ResultSet rs = st.getResultSet();

            while (rs.next()) {

                first_name.set(rs.getString(2));
                age.set(rs.getInt(3));
                salary.set(rs.getDouble(4));
                address = rs.getString(6);
                postalCode = (rs.getString(7));
                phone_ = rs.getString(8);
                country.set(rs.getString(9));
                city.set(rs.getString(10));

                sb.append("First name: " + first_name.get() + "\nAge: " + age.get() + "\nSalary: " + salary.get() + "\nAddress: " + address + "\n"
                        + "Postal code: " + postalCode + "\n"
                        + "Phone: " + phone_ + "\n"
                        + "Country: " + country.get() + "\n"
                        + "City: " + city.get() + "\n");
                sb.append("---------------------------------------------------------------\n");

            }
        } catch (SQLException ex) {
            sb.append(ex.getMessage());

        }
        return sb.toString();
    }

    //check if the Employee ID exists in employee_db
    public static int verifyEmployeeID(int employee_id) {

        Employee empl = null;
        Integer result = null;

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Statement st = conn.createStatement();
            st.executeQuery("call verifyEmployeeID(" + employee_id + ")");

            ResultSet rs = st.getResultSet();

            while (rs.next()) {

                result = rs.getInt(1);
            }

        } catch (SQLException ex) {
            System.out.println("Error in database connection: \n" + ex.getMessage());

        }
        return result;
    }

    //returns the id of employee if exist, by first name and phone details,if not returns 0.
    public static int verifyEmployeeIDByDetails(String first_name, String phone) {

        Employee empl = null;
        Integer result = null;

        try (java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:54986/employee_db",
                "root", "new_password");) {

            Statement st = conn.createStatement();
            st.executeQuery("call verifyEmployeeIDByDetails(" + "'" + first_name + "'" + "," + "'" + phone + "'" + ")");

            ResultSet rs = st.getResultSet();

            while (rs.next()) {

                result = rs.getInt(1);
            }

        } catch (SQLException ex) {
            System.out.println("Error in database connection: \n" + ex.getMessage());

        }
        return result;
    }

    public String getFirstName() {
        return first_name.get();
    }

    public void setFirstName(String first_name) {
        this.first_name.set(first_name);
    }

    public StringProperty firstNameProperty() {
        return first_name;
    }

    public int getAge() {
        return age.get();
    }

    public void setAge(int age) {
        this.age.set(age);
    }

    public IntegerProperty ageProperty() {
        return age;
    }

    public int getAddress_id() {
        return address_id.get();
    }

    public void setAddress_id(int address_id) {
        this.address_id.set(address_id);
    }

    public IntegerProperty address_IdProperty() {
        return address_id;
    }

    public double getSalary() {
        return salary.get();
    }

    public void setSalary(double salary) {
        this.salary.set(salary);
    }

    public DoubleProperty salaryProperty() {
        return salary;
    }

    public int getEmployee_id() {
        return employee_id.get();
    }

    public void setEmployee_id(int employee_id) {
        this.employee_id.set(employee_id);
    }

    public IntegerProperty employee_idProperty() {
        return employee_id;
    }

    public String getPhone() {
        return phone.get();
    }

    public void setPhone(String phone) {
        this.phone.set(phone);
    }

    public StringProperty phoneProperty() {
        return phone;
    }

}
