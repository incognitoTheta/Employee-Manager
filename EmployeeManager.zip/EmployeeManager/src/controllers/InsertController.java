package controllers;

import java.io.IOException;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import models.Address;
import models.City;
import models.Employee;

public class InsertController {

    @FXML
    private TextField firstName;
    @FXML
    private TextField age;
    @FXML
    private TextField salary;
    @FXML
    private TextField address;
    @FXML
    private TextField postalCode;
    @FXML
    private TextField phone;
    @FXML
    private ComboBox<String> city;
    @FXML
    private ComboBox<String> country;
    @FXML
    private Label msgLabel;
    @FXML
    private Label firstNameLabel;
    @FXML
    private Label ageLabel;
    @FXML
    private Label salaryLabel;
    @FXML
    private Label addressLabel;
    @FXML
    private Label postalCodeLabel;
    @FXML
    private Label phoneLabel;
    @FXML
    private Label countryLabel;
    @FXML
    private Label cityLabel;

    public InsertController() {

    }

    public void initialize() {

        try {
            country.getItems().add("Romania");
        } catch (NullPointerException e) {

        }
        firstName.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z*")) {
                firstName.setText(newValue.replaceAll("[^\\sa-zA-Z]", ""));
            }
        });
        age.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                age.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        salary.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                salary.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        postalCode.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                postalCode.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        phone.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                phone.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

    }

    //verifies the value selected in country ComboBox and add city items
    @FXML
    public void chooseCountry() {

        if (country.valueProperty().getValue().equals("Romania")) {
            try {
                if (country.valueProperty().getValue().equals("Romania")) {
                    city.getItems().addAll("Bucuresti", "Brasov", "Cluj", "Timisoara", "Iasi");
                }
            } catch (NullPointerException e) {
            }
        }

    }

    //returns city id from selected city in ComboBox
    @FXML
    public int getSelectedCityID() {

        int cityID = 0;
        try {
            if (!city.valueProperty().getValue().equals("")) {
                City c = new City();
                cityID = c.checkCityID(city.valueProperty().getValue());
            }
        } catch (NullPointerException e) {

        }

        return cityID;
    }

    //insert data from textfields into employee_db tables
    @FXML
    public void insert() throws IOException {

        if (!firstName.getText().equals("") && !age.getText().equals("") && !salary.getText().equals("")) {
            if (!address.getText().equals("") && !postalCode.getText().equals("") && !phone.getText().equals("")) {

                boolean isCountryEmpty = (country.getValue() != null);
                boolean isCityEmpty = (city.getValue() != null);

                if (isCountryEmpty && isCityEmpty) {
                    Address add = new Address();
                    int addressID = add.insertAddress(address.getText(), postalCode.getText(), getSelectedCityID());

                    try {

                        Employee.insertEmployee(firstName.getText(), Integer.valueOf(age.getText()), addressID, Double.parseDouble(salary.getText()), phone.getText());

                    } catch (NumberFormatException nfe) {

                    }
                    msgLabel.setText("You inserted the following data:");
                    firstNameLabel.setText("First name: " + firstName.getText());
                    ageLabel.setText("Age: " + age.getText());
                    salaryLabel.setText("Salary: " + salary.getText());
                    addressLabel.setText("Address: " + address.getText());
                    postalCodeLabel.setText("Postal code: " + postalCode.getText());
                    phoneLabel.setText("Phone: " + phone.getText());
                    countryLabel.setText("Country: " + country.getSelectionModel().getSelectedItem());
                    cityLabel.setText("City: " + city.getSelectionModel().getSelectedItem());
                }

            } else {

                msgLabel.setText("Fields must not be null");
                firstNameLabel.setText("");
                ageLabel.setText("");
                salaryLabel.setText("");
                addressLabel.setText("");
                postalCodeLabel.setText("");
                phoneLabel.setText("");
                countryLabel.setText("");
                cityLabel.setText("");

            }
        } else {
            msgLabel.setText("Fields must not be null");
            firstNameLabel.setText("");
            ageLabel.setText("");
            salaryLabel.setText("");
            addressLabel.setText("");
            postalCodeLabel.setText("");
            phoneLabel.setText("");
            countryLabel.setText("");
            cityLabel.setText("");
        }
    }

    @FXML
    public void closeApplication() {
        Platform.exit();
    }

}
